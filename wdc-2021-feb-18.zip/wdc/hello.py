print('Hello out there!')

# (1) Start a new project in PyCharm
# (2) Start a new file
# (3) Ask the user to give values for x and y
# (4) Check that x and y can be turned into ints
# (5) If so, then turn them into ints, and print them and their sum
# (6) If not, then print an error-like message